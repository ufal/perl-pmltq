<?xml version="1.0" encoding="utf-8"?>

<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="sample1.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94208-126-p1s1">
  <m id="m-ln94208-126-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p1s1w1</w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94208-126-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p1s1w2</w.rf>
   <form>cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94208-126-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p1s1w3</w.rf>
   <form>prorazit</form>
   <lemma>prorazit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94208-126-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p1s1w4</w.rf>
   <form>maltský</form>
   <lemma>maltský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94208-126-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p1s1w5</w.rf>
   <form>beton</form>
   <lemma>beton</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
 </s>
 <s id="m-ln94208-126-p2s1A">
  <m id="m-ln94208-126-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Aw1</w.rf>
   <form>Opava</form>
   <lemma>Opava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Aw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Aw3</w.rf>
   <form>šv</form>
   <lemma>šv-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94208-126-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Aw4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Aw5</w.rf>
   <form>sn</form>
   <lemma>sn-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94208-126-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Aw6</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Aw7</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-126-p2s1B">
  <m id="m-ln94208-126-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw1</w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw2</w.rf>
   <form>jednoznačným</form>
   <lemma>jednoznačný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw3</w.rf>
   <form>cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw4</w.rf>
   <form>vyhrát</form>
   <lemma>vyhrát</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw5</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw6</w.rf>
   <form>Opavě</form>
   <lemma>Opava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw7</w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw8</w.rf>
   <form>Maltou</form>
   <lemma>Malta_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw9</w.rf>
   <form>vstupuje</form>
   <lemma>vstupovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw10</w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw11</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw12</w.rf>
   <form>kvalifikace</form>
   <lemma>kvalifikace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw13</w.rf>
   <form>ME</form>
   <lemma>ME-1_:B_;w_^(mistrovství_Evropy)</lemma>
   <tag>NNNXX-----A---8</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw14</w.rf>
   <form>fotbalový</form>
   <lemma>fotbalový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw15</w.rf>
   <form>tým</form>
   <lemma>tým</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw16</w.rf>
   <form>ČR</form>
   <lemma>ČR-1_:B_;G_^(Česká_republika)</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw17</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw18</w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw19</w.rf>
   <form>let</form>
   <lemma>rok</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s1Bw20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-126-p2s2">
  <m id="m-ln94208-126-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w1</w.rf>
   <form>Vítěz</form>
   <lemma>vítěz</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w2</w.rf>
   <form>skupiny</form>
   <lemma>skupina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w3</w.rf>
   <form>postoupí</form>
   <lemma>postoupit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94208-126-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w4</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-126-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w5</w.rf>
   <form>bojů</form>
   <lemma>boj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w6</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94208-126-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w7</w.rf>
   <form>evropský</form>
   <lemma>evropský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94208-126-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w8</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w9</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94208-126-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w10</w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w11</w.rf>
   <form>pravděpodobnou</form>
   <lemma>pravděpodobný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94208-126-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w12</w.rf>
   <form>účast</form>
   <lemma>účast</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w13</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-126-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w14</w.rf>
   <form>OH</form>
   <lemma>OH-2_:B_;w_^(Olympijské_hry)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-ln94208-126-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w15</w.rf>
   <form>1996</form>
   <lemma>1996</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w16</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-126-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w17</w.rf>
   <form>Atlantě</form>
   <lemma>Atlanta_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s2w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-126-p2s3">
  <m id="m-ln94208-126-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w1</w.rf>
   <form>Malťany</form>
   <form_change>spell</form_change>
   <lemma>Malťan_;E</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w2</w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-ln94208-126-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w3</w.rf>
   <form>osobně</form>
   <lemma>osobně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94208-126-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w4</w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94208-126-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w5</w.rf>
   <form>neviděl</form>
   <lemma>vidět</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ln94208-126-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w7</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w8</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-126-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w9</w.rf>
   <form>mých</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSXP2-S1-------</tag>
  </m>
  <m id="m-ln94208-126-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w10</w.rf>
   <form>informací</form>
   <form_change>spell</form_change>
   <lemma>informace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w11</w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94208-126-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w12</w.rf>
   <form>vše</form>
   <lemma>všechen</lemma>
   <tag>PLNS4---------1</tag>
  </m>
  <m id="m-ln94208-126-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w13</w.rf>
   <form>postavené</form>
   <lemma>postavený_^(*3it)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94208-126-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w14</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-126-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w15</w.rf>
   <form>obraně</form>
   <lemma>obrana_^(proti_nepříteli)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w16</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w17</w.rf>
   <form>zabetonují</form>
   <lemma>zabetonovat_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94208-126-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w18</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94208-126-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w19</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94208-126-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w20</w.rf>
   <form>šestnáctkou</form>
   <lemma>šestnáctka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w22</w.rf>
   <form>natahují</form>
   <lemma>natahovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94208-126-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w23</w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s3w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-126-p2s4">
  <m id="m-ln94208-126-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w1</w.rf>
   <form>Musíme</form>
   <lemma>muset</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-ln94208-126-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w2</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94208-126-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w3</w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94208-126-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w4</w.rf>
   <form>trpěliví</form>
   <lemma>trpělivý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94208-126-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w5</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-126-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w6</w.rf>
   <form>říká</form>
   <lemma>říkat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94208-126-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w7</w.rf>
   <form>trenér</form>
   <lemma>trenér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w8</w.rf>
   <form>českého</form>
   <lemma>český</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94208-126-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w9</w.rf>
   <form>výběru</form>
   <lemma>výběr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w10</w.rf>
   <form>Ivan</form>
   <lemma>Ivan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w11</w.rf>
   <form>Kopecký</form>
   <lemma>Kopecký_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-126-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-126-p2s4w12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-077-p1s1">
  <m id="m-mf930709-077-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p1s1w1</w.rf>
   <form>Dvakrát</form>
   <lemma>dvakrát`2</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m-mf930709-077-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p1s1w2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930709-077-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p1s1w3</w.rf>
   <form>mistra</form>
   <lemma>mistr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-mf930709-077-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p1s1w4</w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-mf930709-077-p2s1A">
  <m id="m-mf930709-077-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Aw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-077-p2s1B">
  <m id="m-mf930709-077-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw2</w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw3</w.rf>
   <form>začnou</form>
   <lemma>začít-1</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw4</w.rf>
   <form>souběžně</form>
   <lemma>souběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw5</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP1----------</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw6</w.rf>
   <form>šachové</form>
   <lemma>šachový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw7</w.rf>
   <form>zápasy</form>
   <lemma>zápas</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw9</w.rf>
   <form>jejichž</form>
   <lemma>jenž_^(který...[ve_vedl._větě])</lemma>
   <tag>P1XXXXP3-------</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw10</w.rf>
   <form>vítězové</form>
   <lemma>vítěz</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw11</w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X3----------</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw12</w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AA---</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw13</w.rf>
   <form>přisuzovat</form>
   <lemma>přisuzovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw14</w.rf>
   <form>korunu</form>
   <lemma>koruna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw15</w.rf>
   <form>šachového</form>
   <lemma>šachový</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw16</w.rf>
   <form>krále</form>
   <lemma>král</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s1Bw17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-077-p2s2">
  <m id="m-mf930709-077-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-077-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w2</w.rf>
   <form>Londýně</form>
   <lemma>Londýn_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w3</w.rf>
   <form>nastoupí</form>
   <lemma>nastoupit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf930709-077-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w4</w.rf>
   <form>Garri</form>
   <lemma>Garri_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w5</w.rf>
   <form>Kasparov</form>
   <lemma>Kasparov_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w6</w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-mf930709-077-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w7</w.rf>
   <form>Nigelu</form>
   <lemma>Nigel_;Y</lemma>
   <tag>NNMS3-----A---1</tag>
  </m>
  <m id="m-mf930709-077-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w8</w.rf>
   <form>Shortovi</form>
   <lemma>Short_;S</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-077-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w11</w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w12</w.rf>
   <form>neurčeném</form>
   <lemma>určený_^(*3it)</lemma>
   <tag>AANS6----1N----</tag>
  </m>
  <m id="m-mf930709-077-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w13</w.rf>
   <form>nizozemském</form>
   <lemma>nizozemský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-mf930709-077-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w14</w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w15</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf930709-077-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w16</w.rf>
   <form>střetnou</form>
   <lemma>střetnout_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-mf930709-077-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w17</w.rf>
   <form>Anatolij</form>
   <lemma>Anatolij_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w18</w.rf>
   <form>Karpov</form>
   <lemma>Karpov_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w20</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w21</w.rf>
   <form>Timman</form>
   <lemma>Timman_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s2w22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-077-p2s3">
  <m id="m-mf930709-077-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w1</w.rf>
   <form>Mistr</form>
   <lemma>mistr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w2</w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w3</w.rf>
   <form>Kasparov</form>
   <lemma>Kasparov_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w5</w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w6</w.rf>
   <form>známo</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-mf930709-077-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w8</w.rf>
   <form>nepřistoupil</form>
   <lemma>přistoupit_:W</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-mf930709-077-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w9</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930709-077-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w10</w.rf>
   <form>finanční</form>
   <lemma>finanční</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-mf930709-077-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w11</w.rf>
   <form>podmínky</form>
   <lemma>podmínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w12</w.rf>
   <form>Mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf930709-077-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w13</w.rf>
   <form>šachové</form>
   <lemma>šachový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf930709-077-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w14</w.rf>
   <form>federace</form>
   <lemma>federace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w15</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w16</w.rf>
   <form>FIDE</form>
   <lemma>FIDE_:B_;K</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-mf930709-077-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w17</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s3w18</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-077-p2s4">
  <m id="m-mf930709-077-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w1</w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-mf930709-077-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w2</w.rf>
   <form>němu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m-mf930709-077-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf930709-077-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w4</w.rf>
   <form>připojil</form>
   <lemma>připojit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-mf930709-077-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w5</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w6</w.rf>
   <form>anglický</form>
   <lemma>anglický</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-mf930709-077-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w7</w.rf>
   <form>vyzývatel</form>
   <lemma>vyzývatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w8</w.rf>
   <form>Nigel</form>
   <lemma>Nigel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w9</w.rf>
   <form>Short</form>
   <lemma>Short_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w11</w.rf>
   <form>FIDE</form>
   <lemma>FIDE_:B_;K</lemma>
   <tag>NNFXX-----A---8</tag>
  </m>
  <m id="m-mf930709-077-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w12</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-077-p2s4w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w13</w.rf>
   <form>marném</form>
   <lemma>marný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-mf930709-077-p2s4w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w14</w.rf>
   <form>jednání</form>
   <lemma>jednání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s4w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w15</w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-mf930709-077-p2s4w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w16</w.rf>
   <form>diskvalifikovala</form>
   <lemma>diskvalifikovat_:T_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-mf930709-077-p2s4w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s4w17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-077-p2s5">
  <m id="m-mf930709-077-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w1</w.rf>
   <form>Právo</form>
   <lemma>právo_^(právo_na_něco;_také_jako_obor)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w2</w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf930709-077-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w3</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930709-077-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w4</w.rf>
   <form>titul</form>
   <lemma>titul</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w5</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w6</w.rf>
   <form>přešlo</form>
   <lemma>přejít</lemma>
   <tag>VpNS---XR-AA---</tag>
  </m>
  <m id="m-mf930709-077-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930709-077-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w8</w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-mf930709-077-p2s5w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w9</w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>ClYP4----------</tag>
  </m>
  <m id="m-mf930709-077-p2s5w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w10</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf930709-077-p2s5w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w11</w.rf>
   <form>turnaje</form>
   <lemma>turnaj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s5w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w12</w.rf>
   <form>kandidátů</form>
   <lemma>kandidát</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s5w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w13</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s5w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w14</w.rf>
   <form>exmistra</form>
   <lemma>exmistr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s5w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w15</w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s5w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w16</w.rf>
   <form>Karpova</form>
   <lemma>Karpov_;S</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s5w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w17</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930709-077-p2s5w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w18</w.rf>
   <form>Nizozemce</form>
   <lemma>Nizozemec_;E</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s5w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w19</w.rf>
   <form>Timmana</form>
   <lemma>Timman_;S</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-mf930709-077-p2s5w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf930709-077-p2s5w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-114-p1s1">
  <m id="m-ln94208-114-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p1s1w1</w.rf>
   <form>Triatlonistky</form>
   <lemma>triatlonistka_^(*2a)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p1s1w2</w.rf>
   <form>stávkovaly</form>
   <lemma>stávkovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
 </s>
 <s id="m-ln94208-114-p2s1A">
  <m id="m-ln94208-114-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Aw1</w.rf>
   <form>Zlín</form>
   <lemma>Zlín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-114-p2s1B">
  <m id="m-ln94208-114-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw1</w.rf>
   <form>Vítěz</form>
   <lemma>vítěz</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw2</w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw3</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw4</w.rf>
   <form>závodu</form>
   <lemma>závod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw5</w.rf>
   <form>Českého</form>
   <lemma>český</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw6</w.rf>
   <form>poháru</form>
   <lemma>pohár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw7</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw8</w.rf>
   <form>triatlonu</form>
   <lemma>triatlon</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw9</w.rf>
   <form>Tomáš</form>
   <lemma>Tomáš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw10</w.rf>
   <form>Kočař</form>
   <lemma>Kočař_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw11</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw12</w.rf>
   <form>Kepák</form>
   <lemma>Kepák_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw13</w.rf>
   <form>JOKO</form>
   <lemma>Joko_;K</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw14</w.rf>
   <form>týmu</form>
   <lemma>tým</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw15</w.rf>
   <form>Brno</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw16</w.rf>
   <form>získal</form>
   <lemma>získat_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw17</w.rf>
   <form>vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw18</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw19</w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw20</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw21</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw22</w.rf>
   <form>Grand</form>
   <lemma>Grand-1_;m_,t_^(v_názvech)</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw23</w.rf>
   <form>Prix</form>
   <lemma>Prix-2_;m_,t_^(cena)</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw24</w.rf>
   <form>Joko</form>
   <lemma>Joko_;K</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw25</w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw26</w.rf>
   <form>nejvyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw27</w.rf>
   <form>koeficient</form>
   <lemma>koeficient</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw28</w.rf>
   <form>1.5</form>
   <lemma>1.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw29</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw30</w.rf>
   <form>plných</form>
   <lemma>plný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw31</w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw32</w.rf>
   <form>tisíc</form>
   <lemma>tisíc-1`1000</lemma>
   <tag>ClXS2----------</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw33</w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s1Bw34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s1Bw34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-114-p2s2">
  <m id="m-ln94208-114-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s2w1</w.rf>
   <form>Druhý</form>
   <lemma>druhý-2</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m-ln94208-114-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s2w2</w.rf>
   <form>skončil</form>
   <lemma>skončit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94208-114-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s2w3</w.rf>
   <form>Seidl</form>
   <lemma>Seidl_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s2w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-114-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s2w5</w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m-ln94208-114-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s2w6</w.rf>
   <form>Slovák</form>
   <lemma>Slovák_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s2w7</w.rf>
   <form>Baran</form>
   <lemma>Baran_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p2s2w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-114-p3s1">
  <m id="m-ln94208-114-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w1</w.rf>
   <form>Start</form>
   <lemma>start</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w2</w.rf>
   <form>závodu</form>
   <lemma>závod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w3</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w4</w.rf>
   <form>luhačovické</form>
   <lemma>luhačovický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w5</w.rf>
   <form>přehradě</form>
   <lemma>přehrada</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w6</w.rf>
   <form>poznamenala</form>
   <lemma>poznamenat_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94208-114-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w7</w.rf>
   <form>stávka</form>
   <lemma>stávka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w8</w.rf>
   <form>žen</form>
   <lemma>žena</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w10</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w11</w.rf>
   <form>odmítly</form>
   <lemma>odmítnout_:W</lemma>
   <tag>VpTP---XR-AA--1</tag>
  </m>
  <m id="m-ln94208-114-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w12</w.rf>
   <form>nastoupit</form>
   <lemma>nastoupit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w13</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w14</w.rf>
   <form>závodu</form>
   <lemma>závod</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w15</w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w16</w.rf>
   <form>organizačním</form>
   <lemma>organizační</lemma>
   <tag>AAIP3----1A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w17</w.rf>
   <form>zmatkům</form>
   <lemma>zmatek</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w18</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w19</w.rf>
   <form>chyběla</form>
   <lemma>chybět_:T_^(někde_něco_chybí)</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94208-114-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w20</w.rf>
   <form>sanitka</form>
   <lemma>sanitka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w22</w.rf>
   <form>motocykly</form>
   <lemma>motocykl</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w23</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w24</w.rf>
   <form>rozhodčí</form>
   <lemma>rozhodčí</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w25</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w26</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w27</w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w28</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w29</w.rf>
   <form>start</form>
   <lemma>start</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w30</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w31</w.rf>
   <form>hodinu</form>
   <lemma>hodina_^(jednotka_času)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s1w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w32</w.rf>
   <form>posunul</form>
   <lemma>posunout</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94208-114-p3s1w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w33</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94208-114-p3s1w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s1w34</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94208-114-p3s2">
  <m id="m-ln94208-114-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s2w1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94208-114-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s2w2</w.rf>
   <form>plavání</form>
   <lemma>plavání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s2w3</w.rf>
   <form>vedl</form>
   <lemma>vést-1</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94208-114-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s2w4</w.rf>
   <form>Kočař</form>
   <lemma>Kočař_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s2w5</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94208-114-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s2w6</w.rf>
   <form>půl</form>
   <lemma>půl-2</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s2w7</w.rf>
   <form>minuty</form>
   <lemma>minuta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s2w8</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94208-114-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s2w9</w.rf>
   <form>Krňávkem</form>
   <lemma>Krňávek_;S</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94208-114-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94208-114-p3s2w10</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-33-p1s1">
  <m id="m-ln94207-33-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p1s1w1</w.rf>
   <form>Mitterrand</form>
   <lemma>Mitterrand_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-33-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p1s1w2</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-33-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p1s1w3</w.rf>
   <form>svém</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS6----------</tag>
  </m>
  <m id="m-ln94207-33-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p1s1w4</w.rf>
   <form>postoji</form>
   <lemma>postoj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94207-33-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p1s1w5</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94207-33-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p1s1w6</w.rf>
   <form>Pétainovi</form>
   <lemma>Pétain_;S</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
 </s>
 <s id="m-ln94207-33-p2s1A">
  <m id="m-ln94207-33-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Aw1</w.rf>
   <form>Paříž</form>
   <lemma>Paříž_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-33-p2s1B">
  <m id="m-ln94207-33-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw1</w.rf>
   <form>Někdejší</form>
   <lemma>někdejší</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw2</w.rf>
   <form>oddanost</form>
   <lemma>oddanost_^(*4t)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw3</w.rf>
   <form>současného</form>
   <lemma>současný</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw4</w.rf>
   <form>francouzského</form>
   <lemma>francouzský</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw5</w.rf>
   <form>prezidenta</form>
   <lemma>prezident</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw6</w.rf>
   <form>Françoise</form>
   <form_change>spell</form_change>
   <lemma>François_;S_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw7</w.rf>
   <form>Mitterranda</form>
   <lemma>Mitterrand_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw8</w.rf>
   <form>kolaborantské</form>
   <lemma>kolaborantský</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw9</w.rf>
   <form>vládě</form>
   <lemma>vláda</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw10</w.rf>
   <form>maršála</form>
   <lemma>maršál</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw11</w.rf>
   <form>Pétaina</form>
   <lemma>Pétain_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw12</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw13</w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw14</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw15</w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw16</w.rf>
   <form>druhé</form>
   <lemma>druhý-2</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw17</w.rf>
   <form>světové</form>
   <lemma>světový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw18</w.rf>
   <form>válce</form>
   <lemma>válka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw19</w.rf>
   <form>odsouzen</form>
   <lemma>odsoudit</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw20</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw21</w.rf>
   <form>trestu</form>
   <lemma>trest</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw22</w.rf>
   <form>smrti</form>
   <lemma>smrt</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw24</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw25</w.rf>
   <form>hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw26</w.rf>
   <form>náplní</form>
   <lemma>náplň</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw27</w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw28</w.rf>
   <form>knihy</form>
   <lemma>kniha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw29</w.rf>
   <form>Francouzské</form>
   <lemma>francouzský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw30</w.rf>
   <form>mládí</form>
   <lemma>mládí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw31</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw32</w.rf>
   <form>jež</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>PJFS1----------</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw33</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw34</w.rf>
   <form>právě</form>
   <lemma>právě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw35</w.rf>
   <form>objevila</form>
   <lemma>objevit_:W</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw36</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw37</w.rf>
   <form>pultech</form>
   <lemma>pult</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw38</w.rf>
   <form>pařížských</form>
   <lemma>pařížský</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw39">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw39</w.rf>
   <form>obchodů</form>
   <lemma>obchod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s1Bw40">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s1Bw40</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-33-p2s2">
  <m id="m-ln94207-33-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s2w1</w.rf>
   <form>Jejím</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSZS7FS3-------</tag>
  </m>
  <m id="m-ln94207-33-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s2w2</w.rf>
   <form>autorem</form>
   <lemma>autor</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s2w3</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94207-33-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s2w4</w.rf>
   <form>novinář</form>
   <lemma>novinář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s2w5</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-33-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s2w6</w.rf>
   <form>okruhu</form>
   <lemma>okruh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s2w7</w.rf>
   <form>prezidentových</form>
   <lemma>prezidentův_^(*2)</lemma>
   <tag>AUMP2M---------</tag>
  </m>
  <m id="m-ln94207-33-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s2w8</w.rf>
   <form>známých</form>
   <lemma>známý-1_^(potkat_známého_[člověka])</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s2w9</w.rf>
   <form>Pierre</form>
   <lemma>Pierre_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s2w10</w.rf>
   <form>Péan</form>
   <lemma>Péan_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s2w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-33-p2s3">
  <m id="m-ln94207-33-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w1</w.rf>
   <form>Dlouho</form>
   <lemma>dlouho_^(o_čase;_př._dlouhá_doba)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w2</w.rf>
   <form>tajené</form>
   <lemma>tajený_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w3</w.rf>
   <form>dokumenty</form>
   <lemma>dokument</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w5</w.rf>
   <form>svědectví</form>
   <lemma>svědectví</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w6</w.rf>
   <form>odhalují</form>
   <lemma>odhalovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln94207-33-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w7</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w8</w.rf>
   <form>616</form>
   <lemma>616</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w9</w.rf>
   <form>stranách</form>
   <lemma>strana-4_^(v_knize,_rukopise,...)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w10</w.rf>
   <form>pravicové</form>
   <lemma>pravicový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w12</w.rf>
   <form>nacionalistické</form>
   <lemma>nacionalistický</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w13</w.rf>
   <form>postoje</form>
   <lemma>postoj</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w14</w.rf>
   <form>mladého</form>
   <lemma>mladý</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w15</w.rf>
   <form>Mitterranda</form>
   <lemma>Mitterrand_;S</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w16</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w17</w.rf>
   <form>válkou</form>
   <lemma>válka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w18</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w19</w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w20</w.rf>
   <form>vyústily</form>
   <lemma>vyústit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln94207-33-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w21</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w22</w.rf>
   <form>jeho</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSXXXZS3-------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w23</w.rf>
   <form>dobrovolné</form>
   <lemma>dobrovolný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w24</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w25</w.rf>
   <form>aktivní</form>
   <lemma>aktivní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w26</w.rf>
   <form>zapojení</form>
   <lemma>zapojení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w27</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w28</w.rf>
   <form>antisemitské</form>
   <lemma>antisemitský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w29</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w30</w.rf>
   <form>rasistické</form>
   <lemma>rasistický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w31</w.rf>
   <form>politiky</form>
   <lemma>politika_^(věda)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w32</w.rf>
   <form>francouzské</form>
   <lemma>francouzský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w33</w.rf>
   <form>kolaborantské</form>
   <lemma>kolaborantský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w34</w.rf>
   <form>vlády</form>
   <lemma>vláda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w35</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w36</w.rf>
   <form>sídlem</form>
   <lemma>sídlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w37</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94207-33-p2s3w38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w38</w.rf>
   <form>Vichy</form>
   <lemma>Vichy_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-ln94207-33-p2s3w39">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94207-33-p2s3w39</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-053-p2s1">
  <m id="m-cmpr9410-053-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p2s1w1</w.rf>
   <form>Zahraniční</form>
   <lemma>zahraniční_,a</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-cmpr9410-053-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p2s1w2</w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p2s1w3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p2s1w4</w.rf>
   <form>my</form>
   <lemma>já</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-053-p3s1">
  <m id="m-cmpr9410-053-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w1</w.rf>
   <form>Americká</form>
   <lemma>americký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w2</w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w3</w.rf>
   <form>Westinghouse</form>
   <lemma>Westinghouse_;K</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w4</w.rf>
   <form>vznikla</form>
   <lemma>vzniknout_:W</lemma>
   <tag>VpQW---XR-AA--1</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w5</w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w6</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w7</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w8</w.rf>
   <form>lety</form>
   <lemma>rok</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w9</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w10</w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w11</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w12</w.rf>
   <form>začala</form>
   <lemma>začít-1</lemma>
   <tag>VpQW---XR-AA---</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w13</w.rf>
   <form>zabývat</form>
   <lemma>zabývat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w14</w.rf>
   <form>produkcí</form>
   <lemma>produkce</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w15</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w16</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w17</w.rf>
   <form>výrobu</form>
   <lemma>výroba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w18</w.rf>
   <form>stejnosměrného</form>
   <lemma>stejnosměrný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w19</w.rf>
   <form>proudu</form>
   <lemma>proud</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s1w20</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-053-p3s2">
  <m id="m-cmpr9410-053-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w2</w.rf>
   <form>současnosti</form>
   <lemma>současnost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w3</w.rf>
   <form>zaměstnává</form>
   <lemma>zaměstnávat-1_:T_^(všeob._význam:_činnost,_zaměstnání)_(*6at-1)</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w4</w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w5</w.rf>
   <form>100000</form>
   <form_change>num_normalization</form_change>
   <lemma>100000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w6</w.rf>
   <form>lidí</form>
   <lemma>člověk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w8</w.rf>
   <form>dosahuje</form>
   <lemma>dosahovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w9</w.rf>
   <form>ročního</form>
   <form_change>spell</form_change>
   <lemma>roční</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w10</w.rf>
   <form>obratu</form>
   <form_change>spell</form_change>
   <lemma>obrat-1_^(z_prodeje_zboží)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w11</w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w12</w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w13</w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w14</w.rf>
   <form>miliard</form>
   <lemma>miliarda`1000000000</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w15</w.rf>
   <form>dolarů</form>
   <lemma>dolar_;b</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s2w16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-053-p3s3">
  <m id="m-cmpr9410-053-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w1</w.rf>
   <form>Přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w2</w.rf>
   <form>působí</form>
   <lemma>působit_:T_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w4</w.rf>
   <form>37</form>
   <lemma>37</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w5</w.rf>
   <form>zemích</form>
   <lemma>země</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w6</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w7</w.rf>
   <form>obchoduje</form>
   <lemma>obchodovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w8</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w9</w.rf>
   <form>více</form>
   <lemma>hodně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w10</w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w11</w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w12</w.rf>
   <form>státy</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s3w13</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-053-p3s4">
  <m id="m-cmpr9410-053-p3s4w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s4w1</w.rf>
   <form>Sídlo</form>
   <lemma>sídlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s4w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s4w2</w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-053-p3s4w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s4w3</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s4w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s4w4</w.rf>
   <form>Pittsburghu</form>
   <lemma>Pittsburgh_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s4w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s4w5</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-cmpr9410-053-p3s4w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s4w6</w.rf>
   <form>státě</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s4w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s4w7</w.rf>
   <form>Pensylvánie</form>
   <lemma>Pensylvánie_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p3s4w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p3s4w8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-053-p4s1">
  <m id="m-cmpr9410-053-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w1</w.rf>
   <form>Společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w2</w.rf>
   <form>nyní</form>
   <lemma>nyní</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w3</w.rf>
   <form>vyrábí</form>
   <lemma>vyrábět_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w4</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w5</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w6</w.rf>
   <form>energetiku</form>
   <lemma>energetika_^(věda)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w8</w.rf>
   <form>elektronické</form>
   <lemma>elektronický</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w9</w.rf>
   <form>systémy</form>
   <lemma>systém</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w11</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w12</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w13</w.rf>
   <form>ochranu</form>
   <lemma>ochrana</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w14</w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w15</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s1w16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9410-053-p4s2">
  <m id="m-cmpr9410-053-p4s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s2w1</w.rf>
   <form>Výrobní</form>
   <lemma>výrobní_,s</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s2w2</w.rf>
   <form>program</form>
   <lemma>program-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s2w3</w.rf>
   <form>doplňují</form>
   <lemma>doplňovat_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-cmpr9410-053-p4s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s2w4</w.rf>
   <form>mobilní</form>
   <lemma>mobilní</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s2w5</w.rf>
   <form>chladící</form>
   <lemma>chladící_^(*3it)</lemma>
   <tag>AGNP1-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s2w6</w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s2w7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9410-053-p4s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s2w8</w.rf>
   <form>vysílací</form>
   <lemma>vysílací_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s2w9</w.rf>
   <form>televizní</form>
   <lemma>televizní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s2w10</w.rf>
   <form>technika</form>
   <lemma>technika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9410-053-p4s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9410-053-p4s2w11</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-110-p1s1">
  <m id="m-mf920925-110-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p1s1w1</w.rf>
   <form>Země</form>
   <lemma>země</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-mf920925-110-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p1s1w2</w.rf>
   <form>střední</form>
   <lemma>střední</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf920925-110-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p1s1w3</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-110-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p1s1w4</w.rf>
   <form>východní</form>
   <lemma>východní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf920925-110-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p1s1w5</w.rf>
   <form>Evropy</form>
   <lemma>Evropa_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-110-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p1s1w6</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920925-110-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p1s1w7</w.rf>
   <form>ES</form>
   <lemma>eso</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-mf920925-110-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p1s1w8</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-mf920925-110-p1s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p1s1w9</w.rf>
   <form>vzdálenější</form>
   <lemma>vzdálený_^(*3it)</lemma>
   <tag>AAFS6----2A----</tag>
  </m>
  <m id="m-mf920925-110-p1s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p1s1w10</w.rf>
   <form>budoucnosti</form>
   <lemma>budoucnost</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
 </s>
 <s id="m-mf920925-110-p2s1">
  <m id="m-mf920925-110-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s1w1</w.rf>
   <form>Londýn</form>
   <lemma>Londýn_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s1w2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-110-p2s2">
  <m id="m-mf920925-110-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w1</w.rf>
   <form>Britské</form>
   <lemma>britský</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w2</w.rf>
   <form>zájmy</form>
   <lemma>zájem</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w3</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-P---3P-AA--1</tag>
  </m>
  <m id="m-mf920925-110-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w4</w.rf>
   <form>zůstat</form>
   <lemma>zůstat</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w5</w.rf>
   <form>prvotní</form>
   <lemma>prvotní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w6</w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-110-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w7</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-110-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w8</w.rf>
   <form>členství</form>
   <lemma>členství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w9</w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w10</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-110-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w11</w.rf>
   <form>Evropském</form>
   <lemma>evropský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w12</w.rf>
   <form>společenství</form>
   <lemma>společenství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-110-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w14</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-110-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w15</w.rf>
   <form>její</form>
   <lemma>jeho_^(přivlast.)</lemma>
   <tag>PSZS1FS3-------</tag>
  </m>
  <m id="m-mf920925-110-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w16</w.rf>
   <form>rozhodování</form>
   <lemma>rozhodování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w17</w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920925-110-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w18</w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w19</w.rf>
   <form>součástí</form>
   <lemma>součást</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w20</w.rf>
   <form>širšího</form>
   <lemma>široký</lemma>
   <tag>AAIS2----2A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w21</w.rf>
   <form>evropského</form>
   <lemma>evropský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w22</w.rf>
   <form>vývoje</form>
   <lemma>vývoj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w23</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-110-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w24</w.rf>
   <form>prohlásil</form>
   <lemma>prohlásit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-mf920925-110-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w25</w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf920925-110-p2s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w26</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-110-p2s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w27</w.rf>
   <form>mimořádném</form>
   <lemma>mimořádný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w28</w.rf>
   <form>zasedání</form>
   <lemma>zasedání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w29</w.rf>
   <form>Dolní</form>
   <lemma>dolní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w30</w.rf>
   <form>sněmovny</form>
   <lemma>sněmovna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w31</w.rf>
   <form>britského</form>
   <lemma>britský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w32</w.rf>
   <form>parlamentu</form>
   <lemma>parlament</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w33</w.rf>
   <form>premiér</form>
   <lemma>premiér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w34</w.rf>
   <form>John</form>
   <lemma>John_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w35</w.rf>
   <form>Major</form>
   <lemma>major</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf920925-110-p2s2w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p2s2w36</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-110-p3s1">
  <m id="m-mf920925-110-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w1</w.rf>
   <form>Uvedl</form>
   <lemma>uvést</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-mf920925-110-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-110-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w3</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf920925-110-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w4</w.rf>
   <form>mimořádný</form>
   <lemma>mimořádný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-mf920925-110-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w5</w.rf>
   <form>summit</form>
   <lemma>summit</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf920925-110-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w6</w.rf>
   <form>nejvyšších</form>
   <lemma>vysoký</lemma>
   <tag>AAMP2----3A----</tag>
  </m>
  <m id="m-mf920925-110-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w7</w.rf>
   <form>představitelů</form>
   <lemma>představitel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-mf920925-110-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w8</w.rf>
   <form>ES</form>
   <lemma>eso</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-mf920925-110-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w9</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf920925-110-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w10</w.rf>
   <form>uskuteční</form>
   <lemma>uskutečnit_:W</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-mf920925-110-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w11</w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920925-110-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w12</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920925-110-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w13</w.rf>
   <form>října</form>
   <lemma>říjen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf920925-110-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-110-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w15</w.rf>
   <form>anglickém</form>
   <lemma>anglický</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-mf920925-110-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w16</w.rf>
   <form>Birminghamu</form>
   <lemma>Birmingham_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-mf920925-110-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p3s1w17</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf920925-110-p4s1">
  <m id="m-mf920925-110-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w1</w.rf>
   <form>Vyslovil</form>
   <lemma>vyslovit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-mf920925-110-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-mf920925-110-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w3</w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920925-110-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w4</w.rf>
   <form>rozšíření</form>
   <lemma>rozšíření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w5</w.rf>
   <form>evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w6</w.rf>
   <form>dvanáctky</form>
   <lemma>dvanáctka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w7</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920925-110-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w8</w.rf>
   <form>skandinávské</form>
   <lemma>skandinávský</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w9</w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-110-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w11</w.rf>
   <form>Rakousko</form>
   <lemma>Rakousko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-110-p4s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w13</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-mf920925-110-p4s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w14</w.rf>
   <form>vzdálenější</form>
   <lemma>vzdálený_^(*3it)</lemma>
   <tag>AAFS6----2A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w15</w.rf>
   <form>budoucnosti</form>
   <lemma>budoucnost</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w16</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf920925-110-p4s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w17</w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w18</w.rf>
   <form>střední</form>
   <lemma>střední</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf920925-110-p4s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w20</w.rf>
   <form>východní</form>
   <lemma>východní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w21</w.rf>
   <form>Evropy</form>
   <lemma>Evropa_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf920925-110-p4s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-mf920925-110-p4s1w22</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-055-p1s1">
  <m id="m-ln95048-055-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p1s1w1</w.rf>
   <form>Jedno</form>
   <lemma>jeden`1</lemma>
   <tag>ClNS1----------</tag>
  </m>
  <m id="m-ln95048-055-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p1s1w2</w.rf>
   <form>srdce</form>
   <lemma>srdce</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln95048-055-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p1s1w3</w.rf>
   <form>ptačí</form>
   <lemma>ptačí</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln95048-055-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p1s1w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p1s1w5</w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>ClXP1----------</tag>
  </m>
  <m id="m-ln95048-055-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p1s1w6</w.rf>
   <form>kapky</form>
   <lemma>kapka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95048-055-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p1s1w7</w.rf>
   <form>žluči</form>
   <lemma>žluč</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-ln95048-055-p2s1A">
  <m id="m-ln95048-055-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Aw1</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Aw2</w.rf>
   <form>NLN</form>
   <lemma>NLN-1_:B_^(Nedělní_LN)</lemma>
   <tag>NNFPX-----A---8</tag>
  </m>
  <m id="m-ln95048-055-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Aw3</w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Aw4</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Aw5</w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Aw6</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Aw7</w.rf>
   <form>1995</form>
   <lemma>1995</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Aw8</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-055-p2s1B">
  <m id="m-ln95048-055-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Bw1</w.rf>
   <form>Uveřejňování</form>
   <lemma>uveřejňování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Bw2</w.rf>
   <form>takových</form>
   <lemma>takový</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m-ln95048-055-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Bw3</w.rf>
   <form>článků</form>
   <lemma>článek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Bw4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95048-055-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Bw5</w.rf>
   <form>nesmírně</form>
   <lemma>nesmírně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95048-055-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Bw6</w.rf>
   <form>důležité</form>
   <lemma>důležitý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln95048-055-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s1Bw7</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-055-p2s2">
  <m id="m-ln95048-055-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w1</w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w2</w.rf>
   <form>revoluci</form>
   <lemma>revoluce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w4</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w5</w.rf>
   <form>různými</form>
   <lemma>různý</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w6</w.rf>
   <form>pavědami</form>
   <lemma>pavěda</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w7</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w8</w.rf>
   <form>šarlatánstvím</form>
   <lemma>šarlatánství</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w9</w.rf>
   <form>roztrhl</form>
   <lemma>roztrhnout_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95048-055-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w10</w.rf>
   <form>pytel</form>
   <lemma>pytel</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w11</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w12</w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PE--4----------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w13</w.rf>
   <form>chápu</form>
   <lemma>chápat</lemma>
   <tag>VB-S---1P-AA---</tag>
  </m>
  <m id="m-ln95048-055-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w15</w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w16</w.rf>
   <form>jednak</form>
   <lemma>jednak</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w17</w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-055-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w18</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w19</w.rf>
   <form>komunismu</form>
   <lemma>komunismus</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w20</w.rf>
   <form>zakázané</form>
   <lemma>zakázaný_^(*2t)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w21</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w22</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w23</w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w24</w.rf>
   <form>logicky</form>
   <lemma>logicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w25</w.rf>
   <form>přitahovaly</form>
   <lemma>přitahovat_:T</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-055-p2s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w26</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w27</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w28</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w29</w.rf>
   <form>druhé</form>
   <lemma>druhý-1_^(jiný)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w30</w.rf>
   <form>nabízejí</form>
   <lemma>nabízet_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln95048-055-p2s2w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w31</w.rf>
   <form>rychlá</form>
   <lemma>rychlý</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w32</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w33</w.rf>
   <form>snadná</form>
   <lemma>snadný</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w34</w.rf>
   <form>řešení</form>
   <lemma>řešení_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w35</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w36</w.rf>
   <form>vysvětlení</form>
   <lemma>vysvětlení_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w37</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w38</w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PE--1----------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w39">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w39</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w40">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w40</w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w41">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w41</w.rf>
   <form>líbí</form>
   <lemma>líbit_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln95048-055-p2s2w42">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w42</w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w43">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w43</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w44">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w44</w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-ln95048-055-p2s2w45">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w45</w.rf>
   <form>neradi</form>
   <lemma>rád</lemma>
   <tag>ACMP------N----</tag>
  </m>
  <m id="m-ln95048-055-p2s2w46">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w46</w.rf>
   <form>myslí</form>
   <lemma>myslit_:T</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-ln95048-055-p2s2w47">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s2w47</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95048-055-p2s3">
  <m id="m-ln95048-055-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w1</w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-ln95048-055-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w2</w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w3</w.rf>
   <form>nechápu</form>
   <lemma>chápat</lemma>
   <tag>VB-S---1P-NA---</tag>
  </m>
  <m id="m-ln95048-055-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w5</w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w6</w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln95048-055-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w7</w.rf>
   <form>stejné</form>
   <lemma>stejný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln95048-055-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w8</w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w9</w.rf>
   <form>vědy</form>
   <lemma>věda</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w10</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w11</w.rf>
   <form>osvěta</form>
   <lemma>osvěta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w12</w.rf>
   <form>vyklidily</form>
   <lemma>vyklidit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-055-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w13</w.rf>
   <form>pole</form>
   <lemma>pole</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w15</w.rf>
   <form>přesněji</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-ln95048-055-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w16</w.rf>
   <form>vyklidily</form>
   <lemma>vyklidit_:W</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-055-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w17</w.rf>
   <form>stránky</form>
   <lemma>stránka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w18</w.rf>
   <form>novin</form>
   <lemma>noviny_^(tisk)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w20</w.rf>
   <form>časopisů</form>
   <lemma>časopis</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w21</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95048-055-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w22</w.rf>
   <form>stáhly</form>
   <lemma>stáhnout</lemma>
   <tag>VpTP---XR-AA---</tag>
  </m>
  <m id="m-ln95048-055-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w23</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95048-055-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w24</w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95048-055-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w25</w.rf>
   <form>ústraní</form>
   <lemma>ústraní</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95048-055-p2s3w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95048-055-p2s3w26</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95047-033-p1s1">
  <m id="m-ln95047-033-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p1s1w1</w.rf>
   <form>Manažer</form>
   <lemma>manažer</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95047-033-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p1s1w2</w.rf>
   <form>Baníku</form>
   <lemma>Baník_;Y</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95047-033-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p1s1w3</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95047-033-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p1s1w4</w.rf>
   <form>vzdal</form>
   <lemma>vzdát</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95047-033-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p1s1w5</w.rf>
   <form>funkce</form>
   <lemma>funkce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-ln95047-033-p2s1A">
  <m id="m-ln95047-033-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Aw1</w.rf>
   <form>Ostrava</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Aw2</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95047-033-p2s1B">
  <m id="m-ln95047-033-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw1</w.rf>
   <form>Manažer</form>
   <lemma>manažer</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw2</w.rf>
   <form>fotbalového</form>
   <lemma>fotbalový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw3</w.rf>
   <form>klubu</form>
   <lemma>klub</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw4</w.rf>
   <form>Baník</form>
   <lemma>Baník_;Y</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw5</w.rf>
   <form>Ostrava</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw6</w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw7</w.rf>
   <form>Pavliska</form>
   <lemma>Pavliska_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw8</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw9</w.rf>
   <form>vzdal</form>
   <lemma>vzdát</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw10</w.rf>
   <form>svého</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw11</w.rf>
   <form>členství</form>
   <lemma>členství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw12</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw13</w.rf>
   <form>ligové</form>
   <lemma>ligový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw14</w.rf>
   <form>komisi</form>
   <lemma>komise</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw15</w.rf>
   <form>ČMFS</form>
   <lemma>ČMFS-1_:B_;K_;w_^(Českomoravský_fotbalový_svaz)</lemma>
   <tag>NNIXX-----A---8</tag>
  </m>
  <m id="m-ln95047-033-p2s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s1Bw16</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln95047-033-p2s2">
  <m id="m-ln95047-033-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w1</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w2</w.rf>
   <form>Nepovažuji</form>
   <lemma>považovat_:T</lemma>
   <tag>VB-S---1P-NA--1</tag>
  </m>
  <m id="m-ln95047-033-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w3</w.rf>
   <form>za</form>
   <lemma>za-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w4</w.rf>
   <form>fair</form>
   <lemma>fair</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w5</w.rf>
   <form>play</form>
   <lemma>play-1_,t</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w7</w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w8</w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-ln95047-033-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w9</w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w10</w.rf>
   <form>objektivních</form>
   <lemma>objektivní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w11</w.rf>
   <form>důvodů</form>
   <lemma>důvod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w12</w.rf>
   <form>požádali</form>
   <lemma>požádat_:W</lemma>
   <tag>VpMP---XR-AA---</tag>
  </m>
  <m id="m-ln95047-033-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w13</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w14</w.rf>
   <form>přeložení</form>
   <lemma>přeložení-1_^(přemístit)_(*5it-1)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w15</w.rf>
   <form>ligového</form>
   <lemma>ligový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w16</w.rf>
   <form>utkání</form>
   <lemma>utkání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w17</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w18</w.rf>
   <form>Drnovicemi</form>
   <lemma>Drnovice_;G</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w19</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w20</w.rf>
   <form>předseda</form>
   <lemma>předseda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w21</w.rf>
   <form>ligové</form>
   <lemma>ligový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w22</w.rf>
   <form>komise</form>
   <lemma>komise</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w23</w.rf>
   <form>pan</form>
   <lemma>pan-1_^(oslovení)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w24</w.rf>
   <form>Novák</form>
   <lemma>Novák_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w25</w.rf>
   <form>naši</form>
   <lemma>můj_^(přivlast.)</lemma>
   <tag>PSFS4-P1-------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w26</w.rf>
   <form>žádost</form>
   <lemma>žádost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w27</w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w28</w.rf>
   <form>nepředložil</form>
   <lemma>předložit_:W</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ln95047-033-p2s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w29</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w30">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w30</w.rf>
   <form>projednání</form>
   <lemma>projednání_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w31">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w31</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w32">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w32</w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w33">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w33</w.rf>
   <form>uvedl</form>
   <lemma>uvést</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln95047-033-p2s2w34">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w34</w.rf>
   <form>Pavliska</form>
   <lemma>Pavliska_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w35">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w35</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w36">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w36</w.rf>
   <form>vysvětlenou</form>
   <lemma>vysvětlená_^(na_vysvětlenou)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w37">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w37</w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-ln95047-033-p2s2w38">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w38</w.rf>
   <form>své</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8FS3---------1</tag>
  </m>
  <m id="m-ln95047-033-p2s2w39">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w39</w.rf>
   <form>demisi</form>
   <lemma>demise</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln95047-033-p2s2w40">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln95047-033-p2s2w40</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-032-p2s1">
  <m id="m-cmpr9413-032-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p2s1w1</w.rf>
   <form>Pozornost</form>
   <lemma>pozornost-2_^(dárek,_úplatek)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p2s1w2</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p2s1w3</w.rf>
   <form>dar</form>
   <lemma>dar</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p2s1w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p2s1w5</w.rf>
   <form>etika</form>
   <lemma>etika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-cmpr9413-032-p3s1A">
  <m id="m-cmpr9413-032-p3s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Aw1</w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Aw2</w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Aw3</w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Aw4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Aw5</w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Aw6</w.rf>
   <form>rozhodování</form>
   <lemma>rozhodování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Aw7</w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Aw8</w.rf>
   <form>obchodních</form>
   <lemma>obchodní</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Aw9</w.rf>
   <form>jednáních</form>
   <lemma>jednání_^(*3at)</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Aw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Aw10</w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-032-p3s1B">
  <m id="m-cmpr9413-032-p3s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Bw1</w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Bw2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Bw3</w.rf>
   <form>pozornost</form>
   <lemma>pozornost-2_^(dárek,_úplatek)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Bw4</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Bw5</w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Bw6</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Bw7</w.rf>
   <form>dar</form>
   <lemma>dar</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s1Bw8</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-032-p3s2">
  <m id="m-cmpr9413-032-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s2w1</w.rf>
   <form>Jaká</form>
   <lemma>jaký</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s2w2</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-032-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s2w3</w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s2w4</w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>P5XP7--3-------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s2w5</w.rf>
   <form>hranice</form>
   <lemma>hranice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s2w6</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-032-p3s3">
  <m id="m-cmpr9413-032-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w1</w.rf>
   <form>Přitom</form>
   <lemma>přitom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w2</w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w3</w.rf>
   <form>víme</form>
   <lemma>vědět</lemma>
   <tag>VB-P---1P-AA---</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w5</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w6</w.rf>
   <form>vhodná</form>
   <lemma>vhodný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w7</w.rf>
   <form>pozornost</form>
   <lemma>pozornost-2_^(dárek,_úplatek)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w8</w.rf>
   <form>dokáže</form>
   <lemma>dokázat</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w9</w.rf>
   <form>vytvořit</form>
   <lemma>vytvořit_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w10</w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w11</w.rf>
   <form>důvěry</form>
   <lemma>důvěra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w12</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w13</w.rf>
   <form>sympatie</form>
   <lemma>sympatie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w14</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w15</w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w16</w.rf>
   <form>určité</form>
   <lemma>určitý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w17</w.rf>
   <form>ledy</form>
   <lemma>led</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w19</w.rf>
   <form>bariéry</form>
   <form_change>spell</form_change>
   <lemma>bariéra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w20</w.rf>
   <form>rezervovanosti</form>
   <lemma>rezervovanost_^(*4t)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w21</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w22</w.rf>
   <form>rychleji</form>
   <lemma>rychle_^(*1ý)</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w23</w.rf>
   <form>rozplynou</form>
   <lemma>rozplynout_:W</lemma>
   <tag>VB-P---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-032-p3s3w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p3s3w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-032-p4s1">
  <m id="m-cmpr9413-032-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w1</w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w2</w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w3</w.rf>
   <form>řádcích</form>
   <lemma>řádek_^(textu)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w4</w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NA---</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w5</w.rf>
   <form>odkaz</form>
   <lemma>odkaz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w6</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w7</w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWIS4----------</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w8</w.rf>
   <form>zákon</form>
   <lemma>zákon</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w9</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w10</w.rf>
   <form>paragraf</form>
   <lemma>paragraf</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w11</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w12</w.rf>
   <form>přesto</form>
   <lemma>přesto</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w13</w.rf>
   <form>půjde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3F-AA---</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w14</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w15</w.rf>
   <form>záležitost</form>
   <lemma>záležitost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w16</w.rf>
   <form>nanejvýš</form>
   <lemma>nanejvýš</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w17</w.rf>
   <form>aktuální</form>
   <lemma>aktuální</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w19</w.rf>
   <form>citlivou</form>
   <lemma>citlivý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w20</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w21</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w22</w.rf>
   <form>podnikatelskou</form>
   <lemma>podnikatelský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w23</w.rf>
   <form>etiku</form>
   <lemma>etika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p4s1w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p4s1w24</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9413-032-p5s1">
  <m id="m-cmpr9413-032-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w1</w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w2</w.rf>
   <form>darem</form>
   <lemma>dar</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w3</w.rf>
   <form>kytka</form>
   <lemma>kytka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w5</w.rf>
   <form>tužka</form>
   <lemma>tužka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w6</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w7</w.rf>
   <form>kalendář</form>
   <lemma>kalendář</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w8</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w9</w.rf>
   <form>kravata</form>
   <lemma>kravata</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w10</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w11</w.rf>
   <form>dárkové</form>
   <lemma>dárkový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w12</w.rf>
   <form>balení</form>
   <lemma>balení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w13</w.rf>
   <form>vína</form>
   <lemma>víno</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w14</w.rf>
   <form>či</form>
   <lemma>či</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w15</w.rf>
   <form>sada</form>
   <lemma>sada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w16</w.rf>
   <form>skleniček</form>
   <lemma>sklenička</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-cmpr9413-032-p5s1w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-cmpr9413-032-p5s1w17</w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-53-p1s1">
  <m id="m-ln94204-53-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p1s1w1</w.rf>
   <form>Vina</form>
   <lemma>vina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94204-53-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p1s1w2</w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94204-53-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p1s1w3</w.rf>
   <form>drah</form>
   <lemma>dráha</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94204-53-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p1s1w4</w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-53-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p1s1w5</w.rf>
   <form>sporná</form>
   <lemma>sporný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
 </s>
 <s id="m-ln94204-53-p2s1A">
  <m id="m-ln94204-53-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Aw1</w.rf>
   <form>Státní</form>
   <lemma>státní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Aw2</w.rf>
   <form>zastupitelství</form>
   <lemma>zastupitelství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Aw3</w.rf>
   <form>posuzuje</form>
   <lemma>posuzovat_:T</lemma>
   <tag>VB-S---3P-AA---</tag>
  </m>
  <m id="m-ln94204-53-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Aw4</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Aw5</w.rf>
   <form>zda</form>
   <lemma>zda</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Aw6</w.rf>
   <form>obžalovat</form>
   <lemma>obžalovat_:W</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Aw7</w.rf>
   <form>E</form>
   <lemma>E-0_:B_;Y</lemma>
   <tag>NNMXX-----A---8</tag>
  </m>
  <m id="m-ln94204-53-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Aw8</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Aw9</w.rf>
   <form>Šípa</form>
   <lemma>Šíp_;S</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
 </s>
 <s id="m-ln94204-53-p2s1B">
  <m id="m-ln94204-53-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Bw1</w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Bw2</w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Bw3</w.rf>
   <form>jap</form>
   <lemma>jap-99_:B_;S</lemma>
   <tag>NNXXX-----A---8</tag>
  </m>
  <m id="m-ln94204-53-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Bw4</w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Bw5</w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-53-p2s1C">
  <m id="m-ln94204-53-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw1</w.rf>
   <form>Generální</form>
   <lemma>generální</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw2</w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw3</w.rf>
   <form>Českých</form>
   <lemma>český</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw4</w.rf>
   <form>drah</form>
   <lemma>dráha</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw5</w.rf>
   <form>Emanuel</form>
   <lemma>Emanuel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw6</w.rf>
   <form>Šíp</form>
   <lemma>Šíp_;S</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw7</w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw8</w.rf>
   <form>neobdržel</form>
   <lemma>obdržet</lemma>
   <tag>VpYS---XR-NA---</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw9</w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWNS4----------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw10</w.rf>
   <form>oznámení</form>
   <lemma>oznámení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw11</w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw12</w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw13</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw14</w.rf>
   <form>že</form>
   <lemma>že</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw15</w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw16</w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw17</w.rf>
   <form>obžalován</form>
   <lemma>obžalovat_:W</lemma>
   <tag>VsYS---XX-AP---</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw18</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw19</w.rf>
   <form>souvislosti</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw20</w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw21</w.rf>
   <form>svým</form>
   <lemma>svůj-1_^(přivlast.)</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw22</w.rf>
   <form>jednáním</form>
   <lemma>jednání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw23</w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw24</w.rf>
   <form>loni</form>
   <lemma>vloni_,h</lemma>
   <tag>Db------------1</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw25</w.rf>
   <form>připravovanou</form>
   <lemma>připravovaný_^(*2t)</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw26</w.rf>
   <form>stávkou</form>
   <lemma>stávka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw27</w.rf>
   <form>železničářů</form>
   <lemma>železničář</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s1Cw28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s1Cw28</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94204-53-p2s2">
  <m id="m-ln94204-53-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w1</w.rf>
   <form>Nehodlá</form>
   <lemma>hodlat_:T</lemma>
   <tag>VB-S---3P-NA---</tag>
  </m>
  <m id="m-ln94204-53-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w2</w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7-X4----------</tag>
  </m>
  <m id="m-ln94204-53-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w3</w.rf>
   <form>tedy</form>
   <lemma>tedy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w4</w.rf>
   <form>vyjadřovat</form>
   <lemma>vyjadřovat_:T</lemma>
   <tag>Vf--------A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w5</w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94204-53-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w6</w.rf>
   <form>informaci</form>
   <lemma>informace</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w7</w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w8</w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94204-53-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w9</w.rf>
   <form>níž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P9FS2----------</tag>
  </m>
  <m id="m-ln94204-53-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w10</w.rf>
   <form>pražský</form>
   <lemma>pražský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w11</w.rf>
   <form>úřad</form>
   <lemma>úřad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w12</w.rf>
   <form>vyšetřování</form>
   <lemma>vyšetřování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w13</w.rf>
   <form>dokončil</form>
   <lemma>dokončit_:W</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-53-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w14</w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94204-53-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w15</w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m-ln94204-53-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w16</w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w17</w.rf>
   <form>šetření</form>
   <lemma>šetření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w18</w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94204-53-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w19</w.rf>
   <form>předal</form>
   <lemma>předat-3_:W_^(někomu_něco)</lemma>
   <tag>VpYS---XR-AA---</tag>
  </m>
  <m id="m-ln94204-53-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w20</w.rf>
   <form>spis</form>
   <lemma>spis</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w21</w.rf>
   <form>městskému</form>
   <lemma>městský</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w22</w.rf>
   <form>státnímu</form>
   <lemma>státní</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w23</w.rf>
   <form>zastupitelství</form>
   <lemma>zastupitelství</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w24</w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94204-53-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w25</w.rf>
   <form>návrhem</form>
   <lemma>návrh</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w26">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w26</w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94204-53-p2s2w27">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w27</w.rf>
   <form>podání</form>
   <lemma>podání_^(něco_[někomu]_[někam])_(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w28">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w28</w.rf>
   <form>obžaloby</form>
   <lemma>obžaloba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94204-53-p2s2w29">
   <src.rf>manual</src.rf>
   <w.rf>w#w-ln94204-53-p2s2w29</w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
